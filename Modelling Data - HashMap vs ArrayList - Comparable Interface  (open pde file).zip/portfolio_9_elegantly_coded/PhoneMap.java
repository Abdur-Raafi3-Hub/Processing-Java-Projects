import java.util.HashMap;
import java.util.ArrayList;
import java.util.Iterator;

public class PhoneMap {

  private HashMap<String, Phone> sup;
  Phone x;

  //please do not question my choice of variable names. it is a p with 3-L's
  public PhoneMap() {
    sup = new HashMap<String, Phone>();
  }


  public void populate(PhoneList pLLL) {
    
    /* so we r gonna basically inherit from the phonelist
     we will iterate thru the phonelist, extracting the name and brandanme
     henceforth conglomerating both attributes into out concatenated string
     which serves as out key
     
     and so, my dear reader, before you is an innovated, enhanced methodology
     in storing data into a hashmap at 2:01 AM, accentuated by the redundant variables
     which serve no purpose but to ease my toiled mind.
     */
    ArrayList<Phone> laListaMakesAReturn = pLLL.returnLaLista();
    int i=0;

    while (i<laListaMakesAReturn.size()) {
      Phone p = laListaMakesAReturn.get(i);
      String name = p.getBrand();
      String model = p.getModel();


      String mashedKey = name+ " " + model;

      x = sup.put(mashedKey, p);

      i++;
    }
    

  }


//this outputs the contents of the hash list
  public String toString() {
    String output = "";

    //for each entry in the hash map
    for (String key : sup.keySet()) {
      //save this to the current object we are iterating from the hashmap ofc
      Phone p = sup.get(key);
      //idk y i called it lene. but its the data of each phone. variables r tider 2 use
      String lene = p.toString() + "\n";

      output += lene;
    }
    return output;
  }
  
  public Phone searchPhone(String brand, String model) {
    return sup.get(brand+" "+model);

  }
  
}
