import java.util.ArrayList;
import java.util.Collections;
import java.lang.Iterable;

public class PhoneList {
  //VARIABLES//
  /*everything is labelled "phone xyz"
   so i called the list as follows */
  ArrayList<Phone> la_lista;


  //CONSTRUCTOR METHOD//
  public PhoneList() {
    la_lista = new ArrayList<Phone>();
  }

  //REST OF METHODS//
  //method to add a new phoe to the arraylist
  public void addPhone(Phone x) {
    la_lista.add(x);
  }
  //method to say how long list is
  public int returnSize() {
    return la_lista.size();
  }

  //output all lists as strings
  public String toString() {
    String output = "";

    //for the entirety of the size of the array
    for (Phone x : la_lista) {
      //idk y i called it lene. but its the data of each phone. variables r tider 2 use
      String lene = x.toString();
      //and add that to the output
      output += (lene + "\n");
    }

    return output;
  }

  //method to sort all data
  public void sort() {
    Collections.sort(la_lista);
  }


  //method to find phones of given company name and model name
  public String search(String brahnd, String módel) {
    //make an output string
    String output = "";

    //search all phones
    for (Phone x : la_lista)
    {
      //saving company model OF THE CURRENT INDEXED PHONE 2 variables
      String thisFirm = x.getBrand();
      String thisModel = x.getModel();

      //if it conforms, then add the "tostring" of this current phone to our output
      if ( módel.equals(thisModel) && brahnd.equals(thisFirm) ) {
        output += x.toString()+"\n";
      }
    }

    //if output is still empty, return error message
    if (output.equals("")) {
      output = "The phone or model you are looking for doesn't exist";
    }

    return output;
  }

  //this method is so that iterating outside of this class wil be easier
  public ArrayList<Phone> returnLaLista() {
    return la_lista;
  }
 
  /* interesting. this method returns a PHONELIST of
   phones more expensive than anm input threshhold
   */
  public PhoneList phonesMoreThan(int threshold)
  {
    int i =0;
    //make the new list
    PhoneList outputPhonelist = new PhoneList();

    //sift thru all phones in la_lista
    while (i<la_lista.size()) {
      //save its price to a variable
      Phone currentPhone = la_lista.get(i);
      int thisPhonesPrice = currentPhone.getApprox_price_EUR();
      //check if the price is more than the one entered
      if (thisPhonesPrice > threshold)
      {
        //if so then add this to out new phonelist
        outputPhonelist.addPhone(currentPhone);
      }
      i++;
    }
    //end iterating thru the original list

    //sort the list
    outputPhonelist.sort();
    //then send it out. NOTE: make a phoneslist var in main
    return outputPhonelist;
  }
}
