import java.util.HashMap; //need to import the library

//make the class
public class StyleCollection {
  
  //DECLARE A HASH
  private HashMap<String,Style> stylesHash;  
  String name;
  
  //CONSTRUCTOR METHOD
  public StyleCollection() {
    stylesHash = new HashMap<String,Style>();
  }
  
  /////////////////////////////////////the rest of the methods/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
  //method to add passend-in style object to the collection
  public void addStyle(Style s){
    
    name = s.getName() ;
    stylesHash.put(name,s);
    
  }
  
  public Style getStyle(String key) {
    return stylesHash.get(key);
  }
   
  //making the just-added style the default one 
  public void setDefaultStyle(Style s){
    stylesHash.put("default",s);
    
  }
  
  public Style getDefaultStyle(){
    Style sendMe = stylesHash.get("default");
    return sendMe; 
  }
}
