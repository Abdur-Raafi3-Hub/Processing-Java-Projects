public class Style {
  
  private int textColor;
  private int strokeColor;
  private int bgColor;
  private int textSize;
  private String name;


  public Style(String name, int bgCol, int stroke, int fill, int tSize) {
    //filling vars w the input
    textColor = fill;  
    this.name = name;
    strokeColor = stroke;
    bgColor = bgCol;
    textSize = tSize;
  }

  public String getName() {
    return name;
  }

  public int getTextColor() {
    return textColor;
  }

  public int getStrokeColor() {
    return strokeColor;
  }

  public int getTextSize() {
    return textSize;
  }

  public int getBackground() {
    return bgColor;
  }
}
